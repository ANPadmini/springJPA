package com.mindtree.sell_your_furniture.modules.product.service;

import java.util.List;

import com.mindtree.sell_your_furniture.modules.product.dto.ProductMaterialDTO;
import com.mindtree.sell_your_furniture.modules.product.entity.ProductMaterial;

public interface ProductMaterialService {

	public List<ProductMaterial> getAllMaterial();

	public List<ProductMaterialDTO> addMaterials(List<ProductMaterialDTO> productMaterials);

}
