package com.mindtree.sell_your_furniture.modules.verificationtoken.entity;

import java.util.UUID;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

import com.mindtree.sell_your_furniture.modules.user.entity.User;

@Entity
public class ResetToken {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long resetTokenId;

	private String token;

	@OneToOne(targetEntity = User.class, fetch = FetchType.EAGER)
	@JoinColumn(nullable = false, name = "user_id")
	private User user;

	public Long getResetTokenId() {
		return resetTokenId;
	}

	public void setResetTokenId(Long resetTokenId) {
		this.resetTokenId = resetTokenId;
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public ResetToken(User user) {
		super();
		this.user = user;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public ResetToken(String token, User user) {
		super();
		this.token = token;
		this.user = user;
	}

	public ResetToken(Long resetTokenId, String token, User user) {
		super();
		this.resetTokenId = resetTokenId;
		this.token = token;
		this.user = user;
	}

	public ResetToken() {
		super();
		this.token = UUID.randomUUID().toString();
		// TODO Auto-generated constructor stub
	}
}
