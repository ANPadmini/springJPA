package com.mindtree.sell_your_furniture.modules.product.service.serviceimpl;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import com.mindtree.sell_your_furniture.modules.product.entity.Product;
import com.mindtree.sell_your_furniture.modules.product.entity.ProductImage;
import com.mindtree.sell_your_furniture.modules.product.repository.ProductImageRepository;
import com.mindtree.sell_your_furniture.modules.product.repository.ProductRepository;
import com.mindtree.sell_your_furniture.modules.product.service.ProductImageService;

@Service
public class ProductImageServiceImpl implements ProductImageService {

	@Autowired
	ProductImageRepository productImageRepository;

	@Autowired
	ProductRepository productRepository;

	@Override
	public List<ProductImage> storeFile(int productId, List<MultipartFile> files) {
		System.out.println("Inside service" + files.size());
		Product product=productRepository.getOne(productId);

		List<ProductImage> savedImages=new ArrayList<ProductImage>();
		files.forEach(file -> {

			String fileName = StringUtils.cleanPath(file.getOriginalFilename());
			ProductImage imageFile = null;
			try {
				imageFile = new ProductImage(fileName, file.getContentType(), file.getBytes());
				imageFile.setProduct(product);
				ProductImage savedImage = productImageRepository.save(imageFile);
				savedImages.add(savedImage);
				
			} catch (IOException e) {

				e.printStackTrace();
			}

		});
		
		product.setProductImages(savedImages);
		return null;
	}

}
