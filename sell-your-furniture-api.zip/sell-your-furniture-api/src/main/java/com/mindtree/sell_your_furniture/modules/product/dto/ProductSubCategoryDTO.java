package com.mindtree.sell_your_furniture.modules.product.dto;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;


public class ProductSubCategoryDTO {

	private int productSubCategoryId;
	private String productSubCategoryType;
	
	@JsonIgnoreProperties("productSubCategoriesDto")
	ProductMainCategoryDTO productMainCategoriesDto;

	public ProductSubCategoryDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ProductSubCategoryDTO(int productSubCategoryId, String productSubCategoryType,
			ProductMainCategoryDTO productMainCategoriesDto) {
		super();
		this.productSubCategoryId = productSubCategoryId;
		this.productSubCategoryType = productSubCategoryType;
		this.productMainCategoriesDto = productMainCategoriesDto;
	}
	

	public int getProductSubCategoryId() {
		return productSubCategoryId;
	}

	public void setProductSubCategoryId(int productSubCategoryId) {
		this.productSubCategoryId = productSubCategoryId;
	}

	public String getProductSubCategoryType() {
		return productSubCategoryType;
	}

	public void setProductSubCategoryType(String productSubCategoryType) {
		this.productSubCategoryType = productSubCategoryType;
	}

	public ProductMainCategoryDTO getProductMainCategoriesDto() {
		return productMainCategoriesDto;
	}

	public void setProductMainCategoriesDto(ProductMainCategoryDTO productMainCategoriesDto) {
		this.productMainCategoriesDto = productMainCategoriesDto;
	}

	@Override
	public String toString() {
		return "ProductSubCategoryDTO [productSubCategoryId=" + productSubCategoryId + ", productSubCategoryType="
				+ productSubCategoryType + ", productMainCategoriesDto=" + productMainCategoriesDto + "]";
	}

	
	
}
