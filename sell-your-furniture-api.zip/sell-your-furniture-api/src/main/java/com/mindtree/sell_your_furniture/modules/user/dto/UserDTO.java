package com.mindtree.sell_your_furniture.modules.user.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

public class UserDTO {

	private int userId;
	private String userName;
	private String userEmail;
	private long userPhone;
	private String userPassword;
	@JsonIgnoreProperties("user")
	private UserLoginDTO userLogin;

	public UserDTO() {
		super();
	}

	public UserDTO(int userId, String userName, String userEmail, long userPhone, String userPassword,
			UserLoginDTO userLogin) {
		super();
		this.userId = userId;
		this.userName = userName;
		this.userEmail = userEmail;
		this.userPhone = userPhone;
		this.userPassword = userPassword;
		this.userLogin = userLogin;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserEmail() {
		return userEmail;
	}

	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}

	public long getUserPhone() {
		return userPhone;
	}

	public void setUserPhone(long userPhone) {
		this.userPhone = userPhone;
	}

	public String getUserPassword() {
		return userPassword;
	}

	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}

	public UserLoginDTO getUserLogin() {
		return userLogin;
	}

	public void setUserLogin(UserLoginDTO userLogin) {
		this.userLogin = userLogin;
	}

}