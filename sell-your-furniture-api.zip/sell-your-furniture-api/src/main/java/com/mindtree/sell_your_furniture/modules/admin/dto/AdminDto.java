package com.mindtree.sell_your_furniture.modules.admin.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

public class AdminDto {

	private int adminId;
	private String adminName;
	private String adminEmail;
	private long adminPhone;
	private String password;
	@JsonIgnoreProperties("admin")
	private AdminLoginDto adminLogin;

	public AdminDto() {
		super();
	}

	public AdminDto(int adminId, String adminName, String adminEmail, long adminPhone, String password,
			AdminLoginDto adminLogin) {
		super();
		this.adminId = adminId;
		this.adminName = adminName;
		this.adminEmail = adminEmail;
		this.adminPhone = adminPhone;
		this.password = password;
		this.adminLogin = adminLogin;
	}

	public int getAdminId() {
		return adminId;
	}

	public void setAdminId(int adminId) {
		this.adminId = adminId;
	}

	public String getAdminName() {
		return adminName;
	}

	public void setAdminName(String adminName) {
		this.adminName = adminName;
	}

	public String getAdminEmail() {
		return adminEmail;
	}

	public void setAdminEmail(String adminEmail) {
		this.adminEmail = adminEmail;
	}

	public long getAdminPhone() {
		return adminPhone;
	}

	public void setAdminPhone(long adminPhone) {
		this.adminPhone = adminPhone;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public AdminLoginDto getAdminLogin() {
		return adminLogin;
	}

	public void setAdminLogin(AdminLoginDto adminLogin) {
		this.adminLogin = adminLogin;
	}

}