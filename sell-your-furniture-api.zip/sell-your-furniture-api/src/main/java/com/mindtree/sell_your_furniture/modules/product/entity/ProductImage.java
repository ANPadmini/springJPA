package com.mindtree.sell_your_furniture.modules.product.entity;

import java.util.Arrays;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;

@Entity
public class ProductImage {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
    private int productImageId;

    private String productImageName;

    private String productImageType;

    @Lob
    private byte[] productImageData;
    
    @ManyToOne
    private Product product;

	public ProductImage() {
		super();
	}

	public ProductImage(int productImageId, String productImageName, String productImageType, byte[] productImageData,
			Product product) {
		super();
		this.productImageId = productImageId;
		this.productImageName = productImageName;
		this.productImageType = productImageType;
		this.productImageData = productImageData;
		this.product = product;
	}
	
	

	public ProductImage(String productImageName, String productImageType, byte[] productImageData) {
		super();
		this.productImageName = productImageName;
		this.productImageType = productImageType;
		this.productImageData = productImageData;
	}

	public int getProductImageId() {
		return productImageId;
	}

	public void setProductImageId(int productImageId) {
		this.productImageId = productImageId;
	}

	public String getProductImageName() {
		return productImageName;
	}

	public void setProductImageName(String productImageName) {
		this.productImageName = productImageName;
	}

	public String getProductImageType() {
		return productImageType;
	}

	public void setProductImageType(String productImageType) {
		this.productImageType = productImageType;
	}

	public byte[] getProductImageData() {
		return productImageData;
	}

	public void setProductImageData(byte[] productImageData) {
		this.productImageData = productImageData;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	@Override
	public String toString() {
		return "ProductImage [productImageId=" + productImageId + ", productImageName=" + productImageName
				+ ", productImageType=" + productImageType + ", productImageData=" + Arrays.toString(productImageData)
				+ ", product=" + product + "]";
	}

    

}
