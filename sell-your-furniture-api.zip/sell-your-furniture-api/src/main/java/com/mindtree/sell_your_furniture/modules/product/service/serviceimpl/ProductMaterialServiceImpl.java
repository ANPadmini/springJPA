package com.mindtree.sell_your_furniture.modules.product.service.serviceimpl;

import java.util.ArrayList;
import java.util.List;

import javax.print.attribute.standard.PDLOverrideSupported;

import org.apache.catalina.mapper.Mapper;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.sell_your_furniture.modules.product.dto.ProductMaterialDTO;
import com.mindtree.sell_your_furniture.modules.product.entity.ProductMaterial;
import com.mindtree.sell_your_furniture.modules.product.repository.ProductMaterialRepository;
import com.mindtree.sell_your_furniture.modules.product.service.ProductMaterialService;

@Service
public class ProductMaterialServiceImpl implements ProductMaterialService{

	@Autowired
	ProductMaterialRepository productMaterialRepository;
	
	public ModelMapper mapper=new ModelMapper();
	
	@Override
	public List<ProductMaterial> getAllMaterial() {
		return productMaterialRepository.findAll();
	}

	@Override
	public List<ProductMaterialDTO> addMaterials(List<ProductMaterialDTO> productMaterials) {
		List<ProductMaterial> savedMaterial=new ArrayList<ProductMaterial>();
		List<ProductMaterialDTO> savedMaterialDtos=new ArrayList<ProductMaterialDTO>(); 
		
		productMaterials.forEach(materialDto->{
			ProductMaterial materialEntity=mapper.map(materialDto, ProductMaterial.class);
			savedMaterial.add(materialEntity);
			
		});
		
	savedMaterial.forEach(material->{
		ProductMaterial resultMaterial=productMaterialRepository.save(material);
		ProductMaterialDTO savedMaterialDto=mapper.map(resultMaterial, ProductMaterialDTO.class);
		savedMaterialDtos.add(savedMaterialDto);
	});
		return savedMaterialDtos;
	}

}
