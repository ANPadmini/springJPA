package com.mindtree.sell_your_furniture.restApiConfig.model;

public class ApiErrorResponse {

}
