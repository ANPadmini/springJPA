package com.mindtree.sell_your_furniture.modules.user.service.serviceimpl;

import java.util.List;
import java.util.stream.Collectors;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.sell_your_furniture.exception.serviceException.EmailAlreadyExitsException;
import com.mindtree.sell_your_furniture.exception.serviceException.EmailNotValidatedException;
import com.mindtree.sell_your_furniture.exception.serviceException.LoginFailureException;
import com.mindtree.sell_your_furniture.exception.serviceException.NosuchUserPresentException;
import com.mindtree.sell_your_furniture.exception.serviceException.PhoneAlreadyExitsException;
import com.mindtree.sell_your_furniture.exception.serviceException.ServiceException;
import com.mindtree.sell_your_furniture.modules.user.dto.UserCountDto;
import com.mindtree.sell_your_furniture.modules.user.dto.UserDTO;
import com.mindtree.sell_your_furniture.modules.user.entity.User;
import com.mindtree.sell_your_furniture.modules.user.entity.UserLogin;
import com.mindtree.sell_your_furniture.modules.user.entity.UserRole;
import com.mindtree.sell_your_furniture.modules.user.repository.UserLoginRepository;
import com.mindtree.sell_your_furniture.modules.user.repository.UserRepository;
import com.mindtree.sell_your_furniture.modules.user.repository.UserRoleRepository;
import com.mindtree.sell_your_furniture.modules.user.service.UserLoginService;
import com.mindtree.sell_your_furniture.modules.user.service.UserService;
import com.mindtree.sell_your_furniture.modules.verificationtoken.service.VerificationTokenService;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	UserLoginService loginService;

	@Autowired
	UserRepository userRepository;

	@Autowired
	UserLoginRepository userLoginRepository;

	@Autowired
	VerificationTokenService verificationTokenService;

	@Autowired
	UserRoleRepository userRoleRepository;

	final String secretKey = "";

	ModelMapper modelMapper = new ModelMapper();

	// Registration
	public User addUser(User user, String originalPassword) throws ServiceException {
		try {

			User userByEmail = userRepository.findByUserEmail(user.getUserEmail());
			User userByPhone = userRepository.findByUserPhone(user.getUserPhone());

			if (userByEmail != null) {
				throw new EmailAlreadyExitsException("Email already Exists");
			} else if (userByPhone != null) {
				throw new PhoneAlreadyExitsException("Phone already Exists");
			} else {
				String encryptedPassword = loginService.encrypt(originalPassword, secretKey);

				UserLogin userLogin = new UserLogin(encryptedPassword);

				 userLogin.setUser(user);
				
				// Initially Set default Role as a Buyer which has id=1
				UserRole role = userRoleRepository.findById(1).get();
				user.setUserRole(role);

				User insertedUser = userRepository.save(user);
			
				userLoginRepository.save(userLogin);
				user.setUserLogin(userLogin);
				
				return insertedUser;
			}

		} catch (EmailAlreadyExitsException e) {

			throw new ServiceException(e.getMessage(), e);
		} catch (PhoneAlreadyExitsException e) {
			throw new ServiceException(e.getMessage(), e);
		}

	}

	// Login
	@Override
	public User validateUser(String email, String password) throws ServiceException {
		try {

			String originalPassword = (String) password;

			User user = userRepository.findByUserEmail(email);

			if (user == null)
				throw new LoginFailureException("Oops Incorrect Email");
			UserLogin userLogin = userLoginRepository.findByUserUserId(user.getUserId());
			if (userLogin == null) {
				throw new LoginFailureException("Please Login With Google");
			} else {
				String encryptedPassword = userLogin.getUserPassword();

				String decryptedPassword = loginService.decrypt(encryptedPassword, secretKey);

				if (originalPassword.equals(decryptedPassword)&& user.isVerified()==false) {
					throw new EmailNotValidatedException("Please Verify Your Email First");
				}
					else if (originalPassword.equals(decryptedPassword)&& user.isVerified()==true) {
					return user;
				} else
					throw new LoginFailureException("Oops Incorrect Password");
			}

		} catch (LoginFailureException e) {
			throw new ServiceException(e.getMessage(), e);
		}

	}

	@Override
	public User addGoogleUser(User user) {
		User testUser = userRepository.findByUserEmail(user.getUserEmail());
		User resultUser = new User();
		if (testUser == null) {
			resultUser = userRepository.save(user);
			return resultUser;
			// System.out.println("inserted");
		} else {
			System.out.println("Not Inserted");
		}
		return testUser;
	}

	@Override
	public List<UserDTO> getAllUsers() {
		List<User> userList = userRepository.findAll();
		return userList.stream().map(e -> convertEntityToDto(e)).collect(Collectors.toList());

	}

	public UserDTO convertEntityToDto(User user) {
		return modelMapper.map(user, UserDTO.class);
	}
	public User convertDtoToEntity(UserDTO userDto) {
		return modelMapper.map(userDto,User.class);
	}

	@Override
	public UserCountDto countData(User user) {

		UserCountDto countRole = new UserCountDto();
		List<User> userList = userRepository.findAll();

		// int countBuyer =
		// userList.stream().filter(e->e.getRole.equals("buyer")).collect(Collectors.toList()).size();
		// int countSeller =
		// userList.stream().filter(e->e.getRole.equals("seller")).collect(Collectors.toList()).size();

		// countRole.setBuyers(countBuyer);
		// countRole.setSellers(countSeller);

		return countRole;

	}
//displaying the user profile
	@Override
	public UserDTO displayUser(int userId) throws ServiceException {
		if(!(userRepository.findById(userId).isPresent()))
		{
			throw new NosuchUserPresentException("No such User exists");
		}
		User user= userRepository.findById(userId).get();
		userRepository.save(user);
		UserDTO userDTO= convertEntityToDto(user);
         return userDTO ;
	}

	@Override
	public UserDTO updateUser(int userId, UserDTO userDto) throws ServiceException {
		if(!(userRepository.findById(userId).isPresent()))
		{
			throw new NosuchUserPresentException("No such User exists");
		}
		User updateUser= userRepository.findById(userId).get();
		User user=convertDtoToEntity(userDto);
		updateUser.setUserName(user.getUserName());
		updateUser.setUserEmail(user.getUserEmail());
		updateUser.setUserPhone(user.getUserPhone());
		userRepository.save(updateUser);
		return convertEntityToDto(updateUser);
	}

}
