package com.mindtree.sell_your_furniture.modules.user.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.stereotype.Repository;

import com.mindtree.sell_your_furniture.modules.user.entity.User;
import com.mindtree.sell_your_furniture.modules.user.entity.UserLogin;

@Repository
public interface UserLoginRepository extends JpaRepository<UserLogin, Integer>{

	public UserLogin findByUserUserId(Integer userId);
}
