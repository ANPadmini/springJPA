package com.mindtree.sell_your_furniture.utilities.fileHandling;

public class ConvertMultipartFileToFile {

}
