package com.mindtree.sell_your_furniture.modules.product.service;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.mindtree.sell_your_furniture.modules.product.entity.ProductImage;

public interface ProductImageService {

	public List<ProductImage> storeFile(int productId, List<MultipartFile> files);

}
