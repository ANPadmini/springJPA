package com.mindtree.sell_your_furniture.modules.verificationtoken.service;

import com.mindtree.sell_your_furniture.modules.user.entity.User;

public interface VerificationTokenService {

	public String addToken(User user);

	public String validateUserByToken(String confirmationToken);
}
