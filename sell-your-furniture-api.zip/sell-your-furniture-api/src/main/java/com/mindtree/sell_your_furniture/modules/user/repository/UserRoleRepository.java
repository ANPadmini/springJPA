package com.mindtree.sell_your_furniture.modules.user.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.mindtree.sell_your_furniture.modules.user.entity.UserRole;

@Repository
public interface UserRoleRepository  extends JpaRepository<UserRole, Integer>{

}
