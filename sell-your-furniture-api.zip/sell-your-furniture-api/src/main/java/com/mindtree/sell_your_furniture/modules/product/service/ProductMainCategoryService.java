package com.mindtree.sell_your_furniture.modules.product.service;


import java.util.List;

import com.mindtree.sell_your_furniture.modules.product.dto.ProductMainCategoryDTO;
import com.mindtree.sell_your_furniture.modules.product.entity.ProductMainCategory;

public interface ProductMainCategoryService {
	
	public ProductMainCategoryDTO addMainCategory(ProductMainCategoryDTO mainCategoryDto);

	public List<ProductMainCategory> getAllMainCategory();

}