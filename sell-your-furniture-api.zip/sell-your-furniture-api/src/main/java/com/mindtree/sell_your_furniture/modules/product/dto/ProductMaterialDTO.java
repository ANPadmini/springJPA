package com.mindtree.sell_your_furniture.modules.product.dto;

public class ProductMaterialDTO {

private int productMaterialId;
	
	private String productMaterialName;

	public ProductMaterialDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ProductMaterialDTO(int productMaterialId, String productMaterialName) {
		super();
		this.productMaterialId = productMaterialId;
		this.productMaterialName = productMaterialName;
	}

	public int getProductMaterialId() {
		return productMaterialId;
	}

	public void setProductMaterialId(int productMaterialId) {
		this.productMaterialId = productMaterialId;
	}

	public String getProductMaterialName() {
		return productMaterialName;
	}

	public void setProductMaterialName(String productMaterialName) {
		this.productMaterialName = productMaterialName;
	}

	@Override
	public String toString() {
		return "ProductMaterialDTO [productMaterialId=" + productMaterialId + ", productMaterialName="
				+ productMaterialName + "]";
	}
	
	
}
