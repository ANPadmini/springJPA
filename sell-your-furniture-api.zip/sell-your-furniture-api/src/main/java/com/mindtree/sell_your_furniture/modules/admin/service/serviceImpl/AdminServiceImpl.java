package com.mindtree.sell_your_furniture.modules.admin.service.serviceImpl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.sell_your_furniture.exception.serviceException.EmailAlreadyExitsException;
import com.mindtree.sell_your_furniture.exception.serviceException.LoginFailureException;
import com.mindtree.sell_your_furniture.exception.serviceException.PhoneAlreadyExitsException;
import com.mindtree.sell_your_furniture.exception.serviceException.ResourceNotFoundException;
import com.mindtree.sell_your_furniture.exception.serviceException.ServiceException;
import com.mindtree.sell_your_furniture.modules.admin.dto.AdminDto;
import com.mindtree.sell_your_furniture.modules.admin.dto.AdminLoginDto;
import com.mindtree.sell_your_furniture.modules.admin.service.AdminLoginService;
import com.mindtree.sell_your_furniture.modules.admin.service.AdminService;
import com.mindtree.sell_your_furniture.modules.user.dto.UserCountDto;
import com.mindtree.sell_your_furniture.modules.user.entity.User;
import com.mindtree.sell_your_furniture.modules.user.entity.UserLogin;
import com.mindtree.sell_your_furniture.modules.user.entity.UserRole;
import com.mindtree.sell_your_furniture.modules.user.repository.UserLoginRepository;
import com.mindtree.sell_your_furniture.modules.user.repository.UserRepository;
import com.mindtree.sell_your_furniture.modules.user.repository.UserRoleRepository;

@Service
public class AdminServiceImpl implements AdminService {

	@Autowired
	UserRepository userRepository;

	@Autowired
	UserLoginRepository userLoginRepository;

	@Autowired
	UserRoleRepository userRoleRepository;

	@Autowired
	AdminLoginService adminLoginService;

	final String secretKey = "";

	@Override
	public User validateAdmin(String email, String password) throws ServiceException {

		try {

			String originalPassword = (String) password;

			User user = userRepository.findByUserEmail(email);

			if (user == null)
				throw new LoginFailureException("Oops Incorrect Email");
			UserLogin userLogin = userLoginRepository.findByUserUserId(user.getUserId());
			if (userLogin == null) {
				throw new LoginFailureException("Please Login With Google");
			} else {
				String encryptedPassword = userLogin.getUserPassword();

				String decryptedPassword = adminLoginService.decrypt(encryptedPassword, secretKey);

				if (originalPassword.equals(decryptedPassword)) {
					return user;
				} else
					throw new LoginFailureException("Oops Incorrect Password");
			}

		} catch (LoginFailureException e) {
			throw new ServiceException(e.getMessage(), e);
		}

	}

	@Override
	public UserCountDto getBuyers_Sellers() {

		UserCountDto countRole = new UserCountDto();
		List<User> userList = userRepository.findAll();

		int countBuyer = userList.stream().filter(e -> e.getUserRole().getRoleType().equalsIgnoreCase("buyer"))
				.collect(Collectors.toList()).size();
		int countSeller = userList.stream().filter(e -> e.getUserRole().getRoleType().equalsIgnoreCase("seller"))
				.collect(Collectors.toList()).size();

		// System.out.println(userList.size());
		countRole.setBuyers(countBuyer);
		countRole.setSellers(countSeller);

		return countRole;
	}

	@Override
	public AdminDto addAdmin(AdminDto adminDto, String originalPassword) throws ServiceException {
		adminDto.getAdminPhone();
		User user = new User();
		user.setUserName(adminDto.getAdminName());
		user.setUserEmail(adminDto.getAdminEmail());
		user.setUserPhone(adminDto.getAdminPhone());

		try {

			User userByEmail = userRepository.findByUserEmail(user.getUserEmail());
			User userByPhone = userRepository.findByUserPhone(user.getUserPhone());

			if (userByEmail != null) {
				throw new EmailAlreadyExitsException("Email already Exists");
			} else if (userByPhone != null) {
				throw new PhoneAlreadyExitsException("Phone already Exists");
			} else {
				String encryptedPassword = adminLoginService.encrypt(originalPassword, secretKey);

				UserLogin userLogin = new UserLogin(encryptedPassword);
				user.setUserLogin(userLogin);
				userLogin.setUser(user);

				// Initially Set default Role as a Buyer which has id=1
				UserRole role = userRoleRepository.findById(4).get();
				user.setUserRole(role);
				User insertedUser = userRepository.save(user);
				userLoginRepository.save(userLogin);
				adminDto.setAdminId(insertedUser.getUserId());
				adminDto.setAdminName(insertedUser.getUserName());
				adminDto.setAdminEmail(insertedUser.getUserEmail());
				adminDto.setAdminPhone(insertedUser.getUserPhone());

				return adminDto;
			}

		} catch (EmailAlreadyExitsException e) {

			throw new ServiceException(e.getMessage(), e);
		} catch (PhoneAlreadyExitsException e) {
			throw new ServiceException(e.getMessage(), e);
		}

	}

	@Override
	public Map<String, Boolean> deleteUser(String email) throws ServiceException {
		
		Map<String, Boolean> response;
		 try {
			User user = userRepository.findByUserEmail(email);
		//orElseThrow(()->new ResourceNotFoundException("User not found for this Email"));

			if(user==null) {
				throw new ResourceNotFoundException("User Not Found");
			}
			else {
				userRepository.findByUserEmail(email).setUserRole(null);
				userRepository.delete(user);
				
				 response = new HashMap<>();
			     response.put("deleted", Boolean.TRUE);
			}
			
		 } catch (ResourceNotFoundException e) {
			throw new ServiceException(e.getMessage());
		}
	   return response; 
	
   
	}

}
