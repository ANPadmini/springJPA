package com.mindtree.sell_your_furniture.modules.product.dto;

import java.util.List;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.mindtree.sell_your_furniture.modules.product.entity.ProductImage;
import com.mindtree.sell_your_furniture.modules.product.entity.ProductMainCategory;
import com.mindtree.sell_your_furniture.modules.product.entity.ProductMaterial;
import com.mindtree.sell_your_furniture.modules.product.entity.ProductSubCategory;
import com.mindtree.sell_your_furniture.modules.user.entity.User;

public class ProductInputDTO {
	
	private int productId;
	private String productTitle;
	private int productPrice;
	private String productDescription;
	private int productRating;

	private String productMainCategory;
	private String productSubCategory;
	private String productMaterial;
	public ProductInputDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public ProductInputDTO(int productId, String productTitle, int productPrice, String productDescription,
			int productRating, String productMainCategory, String productSubCategory, String productMaterial) {
		super();
		this.productId = productId;
		this.productTitle = productTitle;
		this.productPrice = productPrice;
		this.productDescription = productDescription;
		this.productRating = productRating;
		this.productMainCategory = productMainCategory;
		this.productSubCategory = productSubCategory;
		this.productMaterial = productMaterial;
	}
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public String getProductTitle() {
		return productTitle;
	}
	public void setProductTitle(String productTitle) {
		this.productTitle = productTitle;
	}
	public int getProductPrice() {
		return productPrice;
	}
	public void setProductPrice(int productPrice) {
		this.productPrice = productPrice;
	}
	public String getProductDescription() {
		return productDescription;
	}
	public void setProductDescription(String productDescription) {
		this.productDescription = productDescription;
	}
	public int getProductRating() {
		return productRating;
	}
	public void setProductRating(int productRating) {
		this.productRating = productRating;
	}
	public String getProductMainCategory() {
		return productMainCategory;
	}
	public void setProductMainCategory(String productMainCategory) {
		this.productMainCategory = productMainCategory;
	}
	public String getProductSubCategory() {
		return productSubCategory;
	}
	public void setProductSubCategory(String productSubCategory) {
		this.productSubCategory = productSubCategory;
	}
	public String getProductMaterial() {
		return productMaterial;
	}
	public void setProductMaterial(String productMaterial) {
		this.productMaterial = productMaterial;
	}
	@Override
	public String toString() {
		return "ProductInputDTO [productId=" + productId + ", productTitle=" + productTitle + ", productPrice="
				+ productPrice + ", productDescription=" + productDescription + ", productRating=" + productRating
				+ ", productMainCategory=" + productMainCategory + ", productSubCategory=" + productSubCategory
				+ ", productMaterial=" + productMaterial + "]";
	}
	
	
	}
