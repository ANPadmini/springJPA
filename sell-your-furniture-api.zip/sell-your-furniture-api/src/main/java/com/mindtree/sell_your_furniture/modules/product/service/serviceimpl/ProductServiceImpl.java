package com.mindtree.sell_your_furniture.modules.product.service.serviceimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.sell_your_furniture.modules.product.entity.Product;
import com.mindtree.sell_your_furniture.modules.product.entity.ProductMainCategory;
import com.mindtree.sell_your_furniture.modules.product.entity.ProductMaterial;
import com.mindtree.sell_your_furniture.modules.product.entity.ProductSubCategory;
import com.mindtree.sell_your_furniture.modules.product.repository.ProductMainCategoryRepository;
import com.mindtree.sell_your_furniture.modules.product.repository.ProductMaterialRepository;
import com.mindtree.sell_your_furniture.modules.product.repository.ProductRepository;
import com.mindtree.sell_your_furniture.modules.product.repository.ProductSubCategoryRepository;
import com.mindtree.sell_your_furniture.modules.product.service.ProductService;
import com.mindtree.sell_your_furniture.modules.user.repository.UserRepository;

@Service
public class ProductServiceImpl implements ProductService{

	@Autowired
	ProductRepository productRepository;
	@Autowired
	ProductMainCategoryRepository productMainCategoryRepository;
	@Autowired
	ProductSubCategoryRepository productSubCategoryRepository;
	@Autowired
	ProductMaterialRepository productMaterialRepository;
	@Autowired
	UserRepository userRepository;
	
	
	@Override
	public Product saveProduct(Product product, int userId, String productMainCategory, String productSubCategory,
			String productMaterial) {
		System.out.println("In Service");
		String materialName=productMaterial.substring(1, productMaterial.length()-1);//since it contains "" ex. "wood" instead of wood
		
ProductSubCategory subCategory=productSubCategoryRepository.findByProductSubCategoryType(productSubCategory);
		product.setProductSubCategory(subCategory);
		
		ProductMaterial material=productMaterialRepository.findByProductMaterialName(materialName);
		product.setProductMaterial(material);
		
		//System.out.println("MAterial"+productMaterial+"Object:"+material);
		product.setUser(userRepository.getOne(userId));
		Product savedProduct=productRepository.save(product);
		
	return savedProduct;
	}

}
