package com.mindtree.sell_your_furniture.modules.verificationtoken.service;

import com.mindtree.sell_your_furniture.modules.user.entity.User;

public interface ResetTokenService {

	public String addResetToken(String userEmail);

	public User changePasswordByResetToken(String confirmRresetToken);
	
	public String changePassword(int userId , String newPassword);
}
