/*package com.mindtree.sell_your_furniture.modules.user.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.mindtree.sell_your_furniture.exception.serviceException.ServiceException;

import com.mindtree.sell_your_furniture.restApiConfig.model.ApiSuccessResponse;

@RestControllerAdvice(assignableTypes = { UserController.class })
public class ResponseHandler {
	    @ExceptionHandler(ServiceException.class)
	    public ResponseEntity<ApiSuccessResponse> ServiceExceptionhandler(Exception e, Throwable cause) {
	    	ApiSuccessResponse response = new ApiSuccessResponse("Exception Message", true, e.getMessage(), HttpStatus.BAD_REQUEST);
	        return new ResponseEntity<ApiSuccessResponse>(response, HttpStatus.OK);
	    }
}

*/