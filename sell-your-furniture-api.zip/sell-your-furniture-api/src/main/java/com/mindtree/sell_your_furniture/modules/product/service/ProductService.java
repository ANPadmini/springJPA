package com.mindtree.sell_your_furniture.modules.product.service;

import com.mindtree.sell_your_furniture.modules.product.entity.Product;

public interface ProductService {

	public Product saveProduct(Product product, int userId, String productMainCategory, String productSubCategory,
			String productMaterial);

}
