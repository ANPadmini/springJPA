package com.mindtree.sell_your_furniture.modules.verificationtoken.service.serviceImpl;



import com.mindtree.sell_your_furniture.modules.verificationtoken.service.ResetTokenService;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import com.mindtree.sell_your_furniture.modules.user.entity.User;
import com.mindtree.sell_your_furniture.modules.user.entity.UserLogin;
import com.mindtree.sell_your_furniture.modules.user.repository.UserLoginRepository;
import com.mindtree.sell_your_furniture.modules.user.repository.UserRepository;
import com.mindtree.sell_your_furniture.modules.user.service.UserLoginService;
import com.mindtree.sell_your_furniture.modules.verificationtoken.entity.ResetToken;
import com.mindtree.sell_your_furniture.modules.verificationtoken.repository.ResetTokenRepository;
import com.mindtree.sell_your_furniture.modules.verificationtoken.service.ResetTokenService;

@Service
public class ResetTokenServiceImpl implements ResetTokenService {

	@Autowired
	ResetTokenRepository resetTokenRepository;

	@Autowired
	private JavaMailSender emailSender;

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private UserLoginRepository userLoginRepository;
	
	@Autowired
	private UserLoginService userLoginService;

	@Override
	public String addResetToken(String userEmail) {
		User user = userRepository.findByUserEmail(userEmail);
		ResetToken resetToken = new ResetToken();
		resetToken.setUser(user);
		System.out.println(resetToken);
		resetTokenRepository.save(resetToken);
		MimeMessage message = emailSender.createMimeMessage();
		MimeMessageHelper mailMessage = new MimeMessageHelper(message);
		// MimeMailMessage mailMessage = new MimeMailMessage();
		try {
			mailMessage.setTo(user.getUserEmail());
		} catch (MessagingException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try {
			mailMessage.setSubject("Please Change your password!!!");
		} catch (MessagingException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try {
			mailMessage.setFrom("orchardkalingaspace@gmail.com");
		} catch (MessagingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			message.setContent("<html lang=\"en\">\r\n" + "  <head>\r\n" + "    <meta charset=\"UTF-8\" />\r\n"
					+ "    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\" />\r\n"
					+ "    <meta http-equiv=\"X-UA-Compatible\" content=\"ie=edge\" />\r\n"
					+ "    <title>Document</title>\r\n" + "  </head>\r\n" + "  <body>\r\n" + "    <h4><strong>Dear "
					+ user.getUserName() + "</strong></h4>\r\n" + "    <br />\r\n" + "    <h3>\r\n"
					+ "      Welcome to Sell Your Furniture. Please Confirm Your Account. Click here \"http://localhost:4200/forgetpasswordvalidation?token="
					+ resetToken.getToken() + "    </h3>\r\n" + "  </body>\r\n" + "</html>",
					"text/html");
		} catch (MessagingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		emailSender.send(message);
		return null;
	}

	@Override
	public User changePasswordByResetToken(String confirmResetToken) {

		ResetToken resetToken = resetTokenRepository.findByToken(confirmResetToken);
		if (resetToken != null) {
			User user = userRepository.findByUserEmailIgnoreCase(resetToken.getUser().getUserEmail());
			return user;
		}
		return null;
	}

	@Override
	public String changePassword(int userId, String newPassword) {
		System.out.println("uId"+userId+"pssword"+newPassword);
		User user = userRepository.findById(userId).get();
		UserLogin userLogin = userLoginRepository.findByUserUserId(userId);
		String secretKey = "";
		String encryptedPassword = userLoginService.encrypt(newPassword, secretKey);
		userLogin.setUserPassword(encryptedPassword);
		userLogin.setUser(user);
		userLoginRepository.save(userLogin);
		return "success";
	}

}
