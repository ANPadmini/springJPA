package com.mindtree.sell_your_furniture.modules.product.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.mindtree.sell_your_furniture.modules.user.entity.User;

@Entity
public class Product {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int productId;
	private String productTitle;
	private int productPrice;
	private String productDescription;
	private int productRating;

	@ManyToOne
	private ProductSubCategory productSubCategory;
	
	@ManyToOne
	private ProductMaterial productMaterial;
	
	@OneToMany(mappedBy="product",cascade=CascadeType.ALL,fetch=FetchType.LAZY)
	private List<ProductImage> productImages;

	@ManyToOne
	private User user;

	public Product() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Product(int productId, String productTitle, int productPrice, String productDescription, int productRating,
			ProductSubCategory productSubCategory, ProductMaterial productMaterial, List<ProductImage> productImages,
			User user) {
		super();
		this.productId = productId;
		this.productTitle = productTitle;
		this.productPrice = productPrice;
		this.productDescription = productDescription;
		this.productRating = productRating;
		this.productSubCategory = productSubCategory;
		this.productMaterial = productMaterial;
		this.productImages = productImages;
		this.user = user;
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public String getProductTitle() {
		return productTitle;
	}

	public void setProductTitle(String productTitle) {
		this.productTitle = productTitle;
	}

	public int getProductPrice() {
		return productPrice;
	}

	public void setProductPrice(int productPrice) {
		this.productPrice = productPrice;
	}

	public String getProductDescription() {
		return productDescription;
	}

	public void setProductDescription(String productDescription) {
		this.productDescription = productDescription;
	}

	public int getProductRating() {
		return productRating;
	}

	public void setProductRating(int productRating) {
		this.productRating = productRating;
	}

	public ProductSubCategory getProductSubCategory() {
		return productSubCategory;
	}

	public void setProductSubCategory(ProductSubCategory productSubCategory) {
		this.productSubCategory = productSubCategory;
	}

	public ProductMaterial getProductMaterial() {
		return productMaterial;
	}

	public void setProductMaterial(ProductMaterial productMaterial) {
		this.productMaterial = productMaterial;
	}

	public List<ProductImage> getProductImages() {
		return productImages;
	}

	public void setProductImages(List<ProductImage> productImages) {
		this.productImages = productImages;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	@Override
	public String toString() {
		return "Product [productId=" + productId + ", productTitle=" + productTitle + ", productPrice=" + productPrice
				+ ", productDescription=" + productDescription + ", productRating=" + productRating
				+ ", productSubCategory=" + productSubCategory + ", productMaterial=" + productMaterial
				+ ", productImages=" + productImages + ", user=" + user + "]";
	}
	

	
}
