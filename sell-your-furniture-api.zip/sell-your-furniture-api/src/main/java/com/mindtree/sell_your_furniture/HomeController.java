package com.mindtree.sell_your_furniture;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HomeController {

	@GetMapping("/")
	public String home()
	{
		
		return "Welcome to my Application";
	}
	
}
