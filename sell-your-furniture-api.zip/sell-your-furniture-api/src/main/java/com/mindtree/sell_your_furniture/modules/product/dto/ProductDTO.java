package com.mindtree.sell_your_furniture.modules.product.dto;

public class ProductDTO {

	private int productId;
	private String productTitle;
	private int productPrice;
	private String productDescription;
	private int productRating;
	public ProductDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public ProductDTO(int productId, String productTitle, int productPrice, String productDescription,
			int productRating) {
		super();
		this.productId = productId;
		this.productTitle = productTitle;
		this.productPrice = productPrice;
		this.productDescription = productDescription;
		this.productRating = productRating;
	}
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public String getProductTitle() {
		return productTitle;
	}
	public void setProductTitle(String productTitle) {
		this.productTitle = productTitle;
	}
	public int getProductPrice() {
		return productPrice;
	}
	public void setProductPrice(int productPrice) {
		this.productPrice = productPrice;
	}
	public String getProductDescription() {
		return productDescription;
	}
	public void setProductDescription(String productDescription) {
		this.productDescription = productDescription;
	}
	public int getProductRating() {
		return productRating;
	}
	public void setProductRating(int productRating) {
		this.productRating = productRating;
	}
	@Override
	public String toString() {
		return "ProductDTO [productId=" + productId + ", productTitle=" + productTitle + ", productPrice="
				+ productPrice + ", productDescription=" + productDescription + ", productRating=" + productRating
				+ "]";
	}

}
