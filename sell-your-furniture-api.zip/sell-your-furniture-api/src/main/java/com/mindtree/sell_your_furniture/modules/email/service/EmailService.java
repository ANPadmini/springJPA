package com.mindtree.sell_your_furniture.modules.email.service;

import org.springframework.mail.SimpleMailMessage;

public interface EmailService {
	
	    public void sendEmail(SimpleMailMessage email);
}
