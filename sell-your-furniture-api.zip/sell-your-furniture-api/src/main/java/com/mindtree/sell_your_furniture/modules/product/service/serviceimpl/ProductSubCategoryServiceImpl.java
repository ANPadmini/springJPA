package com.mindtree.sell_your_furniture.modules.product.service.serviceimpl;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.sell_your_furniture.modules.product.dto.ProductSubCategoryDTO;
import com.mindtree.sell_your_furniture.modules.product.entity.ProductMainCategory;
import com.mindtree.sell_your_furniture.modules.product.entity.ProductSubCategory;
import com.mindtree.sell_your_furniture.modules.product.repository.ProductMainCategoryRepository;
import com.mindtree.sell_your_furniture.modules.product.repository.ProductSubCategoryRepository;
import com.mindtree.sell_your_furniture.modules.product.service.ProductSubCategoryService;

@Service
public class ProductSubCategoryServiceImpl implements ProductSubCategoryService {

	@Autowired
	ProductSubCategoryRepository productSubCategoryRepository;

	@Autowired
	ProductMainCategoryRepository productMainCategoryRepository;

	ModelMapper modelMapper = new ModelMapper();
	
	@Override
	public List<ProductSubCategoryDTO> addSubCategory(List<ProductSubCategoryDTO> productSubCategoryDto,
			String mainCategory) {
		//ProductSubCategory productSubCategory = convertDtoToEntity(productSubCategoryDto);
		List<ProductSubCategory> productSubCategoryEntityList = productSubCategoryDto.stream().map(e->convertDtoToEntity(e)).collect(Collectors.toList());
		
		List<ProductSubCategoryDTO> productSubCategoryDtoList = new ArrayList<ProductSubCategoryDTO>();
		//List<ProductMainCategory> productmainCategory = productMainCategoryRepository.findByproductMainCategoryType(mainCategory);
		ProductMainCategory productMainCategory=new ProductMainCategory();
		productMainCategory=productMainCategoryRepository.findByproductMainCategoryType(mainCategory);
		
		if(productMainCategory.getProductSubCategories().size()==0) {
			productMainCategory.setProductSubCategories(productSubCategoryEntityList);
		}	
		else
		{
			productMainCategory.getProductSubCategories().addAll(productSubCategoryEntityList);
		}
		

		for(ProductSubCategory subCategory:productSubCategoryEntityList)
		{

			subCategory.setProductMainCategory(productMainCategory);
			ProductSubCategory productSubCategory1=productSubCategoryRepository.save(subCategory);
			ProductSubCategoryDTO productSubCategoryDto1=convertEntityToDto(productSubCategory1);
			productSubCategoryDtoList.add(productSubCategoryDto1);
		}
		
		return productSubCategoryDtoList;
	}

	

	public ProductSubCategory convertDtoToEntity(ProductSubCategoryDTO subCategoryDto) {
		return modelMapper.map(subCategoryDto, ProductSubCategory.class);
	}

	public ProductSubCategoryDTO convertEntityToDto(ProductSubCategory subCategory) {
		return modelMapper.map(subCategory, ProductSubCategoryDTO.class);
	}

	

}
