package com.mindtree.sell_your_furniture.modules.admin.service;

import java.util.Map;

import com.mindtree.sell_your_furniture.exception.serviceException.ServiceException;
import com.mindtree.sell_your_furniture.modules.admin.dto.AdminDto;
import com.mindtree.sell_your_furniture.modules.user.dto.UserCountDto;
import com.mindtree.sell_your_furniture.modules.user.entity.User;

public interface AdminService {

	//public User addAdmin(User user, String password) throws ServiceException;

	public User validateAdmin(String email, String password) throws ServiceException;
	
	public UserCountDto getBuyers_Sellers();
	
	public AdminDto addAdmin(AdminDto adminDto, String password) throws ServiceException;
	
	//public AdminDto ValidateAdmin(String email, String password) throws ServiceException;

	public Map<String, Boolean> deleteUser(String email) throws ServiceException; 
}
