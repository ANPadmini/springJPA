package com.mindtree.sell_your_furniture.modules.admin.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

public class AdminLoginDto {

	private int loginId;
	private String userPassword;

	@JsonIgnoreProperties("adminLogin")
	private AdminDto admin;

	public AdminLoginDto() {
		super();
	}

	public AdminLoginDto(int loginId, String userPassword, AdminDto admin) {
		super();
		this.loginId = loginId;
		this.userPassword = userPassword;
		this.admin = admin;
	}

	public int getLoginId() {
		return loginId;
	}

	public void setLoginId(int loginId) {
		this.loginId = loginId;
	}

	public String getUserPassword() {
		return userPassword;
	}

	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}

	public AdminDto getAdmin() {
		return admin;
	}

	public void setAdmin(AdminDto admin) {
		this.admin = admin;
	}

}
