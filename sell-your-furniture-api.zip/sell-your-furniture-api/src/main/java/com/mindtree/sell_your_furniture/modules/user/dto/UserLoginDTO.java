package com.mindtree.sell_your_furniture.modules.user.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

public class UserLoginDTO {

	private int loginId;
	private String userPassword;
	@JsonIgnoreProperties("userLogin")
	private UserDTO user;

	public UserLoginDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public UserLoginDTO(int loginId, String userPassword, UserDTO user) {
		super();
		this.loginId = loginId;
		this.userPassword = userPassword;
		this.user = user;
	}

	@Override
	public String toString() {
		return "UserLoginDTO [loginId=" + loginId + ", userPassword=" + userPassword + ", user=" + user + "]";
	}

	public int getLoginId() {
		return loginId;
	}

	public void setLoginId(int loginId) {
		this.loginId = loginId;
	}

	public String getUserPassword() {
		return userPassword;
	}

	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}

	public UserDTO getUser() {
		return user;
	}

	public void setUser(UserDTO user) {
		this.user = user;
	}

}
