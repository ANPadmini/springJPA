package com.mindtree.sell_your_furniture.modules.verificationtoken.controller;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.sell_your_furniture.modules.user.dto.UserDTO;
import com.mindtree.sell_your_furniture.modules.user.entity.User;
import com.mindtree.sell_your_furniture.modules.verificationtoken.service.ResetTokenService;
import com.mindtree.sell_your_furniture.restApiConfig.model.ApiSuccessResponse;

@RestController
@CrossOrigin
public class ResetTokenController {

	@Autowired
	ResetTokenService resetTokenService;
	
	public ModelMapper mapper=new ModelMapper();
	
	@GetMapping("/generate/token")
	@ResponseBody
	public ResponseEntity<ApiSuccessResponse> resetPasswordToken(@RequestParam String userEmail) {
		System.out.println(userEmail);
		resetTokenService.addResetToken(userEmail);
		return null; 
	}
	
	@GetMapping("/get/user/{token}")
	public ResponseEntity<ApiSuccessResponse> getUserByToken(@PathVariable("token") String token){
		System.out.println(token);
		User user = resetTokenService.changePasswordByResetToken(token);
		UserDTO userDto = mapper.map(user,UserDTO.class);
		return new ResponseEntity<ApiSuccessResponse>(new ApiSuccessResponse("User Information",false,userDto,HttpStatus.OK),HttpStatus.OK); 
	}
	
	@PostMapping("/change/password/{id}/{password}")
	public ResponseEntity<ApiSuccessResponse> changeUserPassword(@PathVariable("id") int userId ,@PathVariable("password") String password){
		resetTokenService.changePassword(userId, password);
		return null;
			
	}
}
