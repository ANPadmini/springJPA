package com.mindtree.sell_your_furniture.modules.user.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.mindtree.sell_your_furniture.modules.user.entity.User;

@Repository
public interface UserRepository extends JpaRepository<User, Integer>{
	
	public User findByUserEmailIgnoreCase(String userEmail);

	public User findByUserEmail(String email);

	public User findByUserPhone(Long phone);

}
