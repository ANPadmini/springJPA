package com.mindtree.sell_your_furniture.modules.user.entity;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class UserLogin {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int loginId;
	private String userPassword;

	@OneToOne
	private User user;

	public UserLogin() {
		super();
		// TODO Auto-generated constructor stub
	}

	public UserLogin(int loginId, String userPassword, User user) {
		super();
		this.loginId = loginId;
		this.userPassword = userPassword;
		this.user = user;
	}

	public UserLogin(String userPassword) {
		this.userPassword=userPassword;
	}

	public int getLoginId() {
		return loginId;
	}

	public void setLoginId(int loginId) {
		this.loginId = loginId;
	}

	public String getUserPassword() {
		return userPassword;
	}

	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	@Override
	public String toString() {
		return "UserLogin [loginId=" + loginId + ", userPassword=" + userPassword + ", user=" + user + "]";
	}
	
	
}
