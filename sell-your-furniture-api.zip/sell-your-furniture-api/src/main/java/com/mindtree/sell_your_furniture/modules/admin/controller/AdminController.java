package com.mindtree.sell_your_furniture.modules.admin.controller;

import java.util.List;
import java.util.Map;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.sell_your_furniture.exception.serviceException.ServiceException;
import com.mindtree.sell_your_furniture.modules.admin.dto.AdminDto;
import com.mindtree.sell_your_furniture.modules.admin.service.AdminService;
import com.mindtree.sell_your_furniture.modules.product.dto.ProductMainCategoryDTO;
import com.mindtree.sell_your_furniture.modules.product.dto.ProductMaterialDTO;
import com.mindtree.sell_your_furniture.modules.product.dto.ProductSubCategoryDTO;
import com.mindtree.sell_your_furniture.modules.product.service.ProductMainCategoryService;
import com.mindtree.sell_your_furniture.modules.product.service.ProductMaterialService;
import com.mindtree.sell_your_furniture.modules.product.service.ProductSubCategoryService;
import com.mindtree.sell_your_furniture.modules.user.dto.UserCountDto;
import com.mindtree.sell_your_furniture.modules.user.dto.UserDTO;
import com.mindtree.sell_your_furniture.modules.user.entity.User;
import com.mindtree.sell_your_furniture.modules.user.service.UserService;
import com.mindtree.sell_your_furniture.restApiConfig.model.ApiSuccessResponse;

import io.swagger.annotations.Api;


@RestController
@CrossOrigin
@Api(value="Operations pertaining to Admin in Sell Your Furniture")
@RequestMapping("/admin")
public class AdminController {

	@Autowired
	AdminService adminService;

	@Autowired
	UserService userService;

	@Autowired
	ProductMainCategoryService mainCategoryService;
	
	@Autowired
	ProductMaterialService productMaterialService;

	@Autowired
	ProductSubCategoryService productSubCategoryService;

	public ModelMapper mapper = new ModelMapper();

	@PostMapping("/sign-up")
	public ResponseEntity<ApiSuccessResponse> signUp(@RequestBody AdminDto adminDto) throws ServiceException {
		User user = new User();

		user.setUserName(adminDto.getAdminName());
		user.setUserEmail(adminDto.getAdminEmail());
		user.setUserPhone(adminDto.getAdminPhone());

		String password = adminDto.getPassword();
		AdminDto result = adminService.addAdmin(adminDto, password);

		AdminDto userDtoResult = mapper.map(result, AdminDto.class);
		return new ResponseEntity<ApiSuccessResponse>(
				new ApiSuccessResponse("Signup Information", false, userDtoResult, HttpStatus.OK), HttpStatus.OK);

	}

	@PostMapping("/sign-in/{email}")
	public ResponseEntity<ApiSuccessResponse> signUp(@PathVariable String email, @RequestBody String password)
			throws ServiceException {
		System.out.println("received Input" + email + ":" + password);
		User adminResult = adminService.validateAdmin(email, password);
		UserDTO resultAdminDto = mapper.map(adminResult, UserDTO.class);

		return new ResponseEntity<ApiSuccessResponse>(
				new ApiSuccessResponse("Login Information", false, resultAdminDto, HttpStatus.OK), HttpStatus.OK);
	}

//	@GetMapping("/getUsers")
//	public ResponseEntity<SuccessResponse> getUsers()
//	{
//		List<UserDTO> userList=userService.getAllUsers();
//		return new ResponseEntity<SuccessResponse>(new SuccessResponse("Login Information",false,userList,HttpStatus.OK),HttpStatus.OK); 
//		
//		
//	}

	@GetMapping("/getBuyerSeller")
	public ResponseEntity<ApiSuccessResponse> getUsers() {
		UserCountDto userCount = adminService.getBuyers_Sellers();
		return new ResponseEntity<ApiSuccessResponse>(
				new ApiSuccessResponse("Buyer and Seller Info.", false, userCount, HttpStatus.OK), HttpStatus.OK);
	}

	@PostMapping("/add/MainCategory")
	public ResponseEntity<ApiSuccessResponse> addMainCategory(@RequestBody ProductMainCategoryDTO productMainCategory) {
		ProductMainCategoryDTO mainCategoryDto = mainCategoryService.addMainCategory(productMainCategory);
		return new ResponseEntity<ApiSuccessResponse>(
				new ApiSuccessResponse("Product Main Category Info.", false, mainCategoryDto, HttpStatus.OK),
				HttpStatus.OK);
	}

	@PostMapping("/add/Material")
	public ResponseEntity<ApiSuccessResponse> addMaterial(@RequestBody List<ProductMaterialDTO> productMaterials) {
		List<ProductMaterialDTO> materialDtos = productMaterialService.addMaterials(productMaterials);
		return new ResponseEntity<ApiSuccessResponse>(
				new ApiSuccessResponse("Product Main Category Info.", false, materialDtos, HttpStatus.OK),
				HttpStatus.OK);
	}

	
	@PostMapping("/add/SubCategory/{mainCategory}")
	public ResponseEntity<ApiSuccessResponse> addSubCategory(@RequestBody List<ProductSubCategoryDTO> productSubCategory,
			@PathVariable String mainCategory) {
		
		List<ProductSubCategoryDTO> subCategoryDto = productSubCategoryService.addSubCategory(productSubCategory,mainCategory);
		return new ResponseEntity<ApiSuccessResponse>(
				new ApiSuccessResponse("Product Sub Catgory Info.", false, subCategoryDto, HttpStatus.OK), HttpStatus.OK);
	}
	
	@DeleteMapping("/deleteUser/{email}")
	public  ResponseEntity<ApiSuccessResponse> deleteEmployeeById(@PathVariable(value="email") String userEmail) throws ServiceException
	{
		Map<String,Boolean> response= adminService.deleteUser(userEmail);
		
		return new ResponseEntity<ApiSuccessResponse>(
				new ApiSuccessResponse("Product Sub Catgory Info.", false, response, HttpStatus.OK), HttpStatus.OK);
	}

}
