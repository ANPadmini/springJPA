package com.mindtree.sell_your_furniture.modules.user.controller;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.sell_your_furniture.exception.serviceException.ServiceException;
import com.mindtree.sell_your_furniture.modules.user.dto.UserDTO;
import com.mindtree.sell_your_furniture.modules.user.entity.User;
import com.mindtree.sell_your_furniture.modules.user.service.UserService;
import com.mindtree.sell_your_furniture.modules.verificationtoken.entity.VerificationToken;
import com.mindtree.sell_your_furniture.modules.verificationtoken.service.VerificationTokenService;
import com.mindtree.sell_your_furniture.restApiConfig.model.ApiSuccessResponse;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;


@RestController
@CrossOrigin
@RequestMapping("/user")
@Api(value="Sell Your Furniture Operations pertaining to users in Sell Your Furniture")
public class UserController {

	@Autowired
	UserService userService;

	public ModelMapper mapper = new ModelMapper();

	@Autowired
	private VerificationTokenService verificationTokenService;
	
	@ApiOperation(value = "Manual Registration of new user")
	@PostMapping("/sign-up") // Registration
	public ResponseEntity<ApiSuccessResponse> signUp(@RequestBody UserDTO userDto) throws ServiceException {

		User user = new User();
		System.out.println("GOT REQUEST" + userDto.getUserName());

		user.setUserName(userDto.getUserName());
		user.setUserEmail(userDto.getUserEmail());
		user.setUserPhone(userDto.getUserPhone());

		String password = userDto.getUserPassword();
		User insertedUser = userService.addUser(user, password);
		this.verificationTokenService.addToken(user);

		UserDTO resultUserDto = mapper.map(insertedUser, UserDTO.class);

		return new ResponseEntity<ApiSuccessResponse>(
				new ApiSuccessResponse("Signup Information", false, resultUserDto, HttpStatus.OK), HttpStatus.OK);

	}

	@PostMapping("/sign-in/{email}") // Manual LOGIN
	public ResponseEntity<ApiSuccessResponse> signIn(@PathVariable String email, @RequestBody String password)
			throws ServiceException {
		System.out.println("received Input" + email + ":" + password);
		User user = userService.validateUser(email, password);
		UserDTO userDto = mapper.map(user, UserDTO.class);
		System.out.println("Sending repsonse" + userDto.getUserName());
		return new ResponseEntity<ApiSuccessResponse>(
				new ApiSuccessResponse("Login Information", false, userDto, HttpStatus.OK), HttpStatus.OK);
	}

	@PostMapping("/login/save-response") // LOGIN Using Google
	public ResponseEntity<ApiSuccessResponse> saveGoogleData(@RequestBody UserDTO googleUser) {

		// Conversion of UserDTO into User Entity
		User user = new User();
		user.setUserName(googleUser.getUserName());
		user.setUserEmail(googleUser.getUserEmail());

		User resultUser = userService.addGoogleUser(user);

		UserDTO resultUserDto = mapper.map(resultUser, UserDTO.class);
		// System.out.println("received Response From Google"+response); //return new
		return new ResponseEntity<ApiSuccessResponse>(
				new ApiSuccessResponse("Google Login Information", false, resultUserDto, HttpStatus.OK), HttpStatus.OK);

	}

	@GetMapping(value = "/confirm-account/{token}")
	public ResponseEntity<ApiSuccessResponse> confirmUserAccount(@PathVariable("token") String confirmationToken) {

		ApiSuccessResponse response = new ApiSuccessResponse();
		System.out.println("inside 123");
		String result = verificationTokenService.validateUserByToken(confirmationToken);
		response.setBody(result);
		return new ResponseEntity<ApiSuccessResponse>(
				new ApiSuccessResponse("Verification of account", false, response, HttpStatus.OK), HttpStatus.OK);
	}
	@PostMapping(value="/displayuser/{userId}")//getting the user details
	public ResponseEntity<ApiSuccessResponse>  displayUser(@PathVariable ("userId") int userId) throws ServiceException 
	{
    	
		UserDTO userDto=userService.displayUser(userId);
		return new ResponseEntity<ApiSuccessResponse>(
				new ApiSuccessResponse("User Profile Information", false, userDto, HttpStatus.OK), HttpStatus.OK);

		
	}
	@PutMapping(value="updateUser/{userId}")
	public ResponseEntity<ApiSuccessResponse> updateUser(@PathVariable ("userId") int userId,@RequestBody UserDTO userDto) throws ServiceException
	{
		UserDTO userDTO=userService.updateUser(userId,userDto);
		return new ResponseEntity<ApiSuccessResponse>(
				new ApiSuccessResponse("Update User  Information", false, userDto, HttpStatus.OK), HttpStatus.OK);

	}

}
