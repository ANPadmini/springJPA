package com.mindtree.sell_your_furniture.modules.product.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.mindtree.sell_your_furniture.modules.product.entity.ProductMaterial;

@Repository
public interface ProductMaterialRepository extends JpaRepository<ProductMaterial, Integer>{

	public ProductMaterial findByProductMaterialName(String productMaterialName);
}
