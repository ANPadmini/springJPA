package com.mindtree.sell_your_furniture.modules.admin.service;
public interface AdminLoginService {
	
	
	public String encrypt(String originalString, String secretKey);

	public String decrypt(String encryptedString, String secretKey);
	



}
