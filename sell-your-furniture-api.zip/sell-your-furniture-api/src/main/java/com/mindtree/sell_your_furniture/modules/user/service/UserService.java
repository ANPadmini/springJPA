package com.mindtree.sell_your_furniture.modules.user.service;

import java.util.List;

import com.mindtree.sell_your_furniture.exception.serviceException.ServiceException;
import com.mindtree.sell_your_furniture.modules.user.dto.UserCountDto;
import com.mindtree.sell_your_furniture.modules.user.dto.UserDTO;
import com.mindtree.sell_your_furniture.modules.user.entity.User;

public interface UserService {

	public User addUser(User user, String password) throws ServiceException;

	public User validateUser(String email, String password) throws ServiceException;

	public User addGoogleUser(User user);

	public List<UserDTO> getAllUsers();

	public UserCountDto countData(User user);

	public UserDTO displayUser(int userId) throws ServiceException;

	public UserDTO updateUser(int userId, UserDTO userDto) throws ServiceException;

}
