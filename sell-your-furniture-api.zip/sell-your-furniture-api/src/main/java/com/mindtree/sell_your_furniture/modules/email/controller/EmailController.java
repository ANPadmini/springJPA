package com.mindtree.sell_your_furniture.modules.email.controller;

public class EmailController {

}
