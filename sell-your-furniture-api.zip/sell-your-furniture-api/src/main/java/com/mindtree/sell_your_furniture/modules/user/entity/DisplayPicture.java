package com.mindtree.sell_your_furniture.modules.user.entity;

import java.util.Arrays;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.OneToOne;

@Entity
public class DisplayPicture {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
    private int displayPictureId;

    private String displayPictureName;

    private String displayPictureType;

    @Lob
    private byte[] displayPictureData;
	
    @OneToOne
    private User user;

	public DisplayPicture() {
		super();
		// TODO Auto-generated constructor stub
	}

	public DisplayPicture(int displayPictureId, String displayPictureName, String displayPictureType,
			byte[] displayPictureData, User user) {
		super();
		this.displayPictureId = displayPictureId;
		this.displayPictureName = displayPictureName;
		this.displayPictureType = displayPictureType;
		this.displayPictureData = displayPictureData;
		this.user = user;
	}

	public int getDisplayPictureId() {
		return displayPictureId;
	}

	public void setDisplayPictureId(int displayPictureId) {
		this.displayPictureId = displayPictureId;
	}

	public String getDisplayPictureName() {
		return displayPictureName;
	}

	public void setDisplayPictureName(String displayPictureName) {
		this.displayPictureName = displayPictureName;
	}

	public String getDisplayPictureType() {
		return displayPictureType;
	}

	public void setDisplayPictureType(String displayPictureType) {
		this.displayPictureType = displayPictureType;
	}

	public byte[] getDisplayPictureData() {
		return displayPictureData;
	}

	public void setDisplayPictureData(byte[] displayPictureData) {
		this.displayPictureData = displayPictureData;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	@Override
	public String toString() {
		return "DisplayPicture [displayPictureId=" + displayPictureId + ", displayPictureName=" + displayPictureName
				+ ", displayPictureType=" + displayPictureType + ", displayPictureData="
				+ Arrays.toString(displayPictureData) + ", user=" + user + "]";
	}
    
    
}
