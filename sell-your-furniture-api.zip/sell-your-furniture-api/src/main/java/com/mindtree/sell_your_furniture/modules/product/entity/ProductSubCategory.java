package com.mindtree.sell_your_furniture.modules.product.entity;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;



@Entity
public class ProductSubCategory {
	
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int productSubCategoryId;
	private String productSubCategoryType;
	
	@ManyToOne
	private ProductMainCategory productMainCategory;

	@OneToMany(mappedBy="productSubCategory",fetch=FetchType.LAZY)
	private List<Product> products;

	public ProductSubCategory() {
		super();
	}

	public ProductSubCategory(int productSubCategoryId, String productSubCategoryType,
			ProductMainCategory productMainCategory, List<Product> products) {
		super();
		this.productSubCategoryId = productSubCategoryId;
		this.productSubCategoryType = productSubCategoryType;
		this.productMainCategory = productMainCategory;
		this.products = products;
	}

	public int getProductSubCategoryId() {
		return productSubCategoryId;
	}

	public void setProductSubCategoryId(int productSubCategoryId) {
		this.productSubCategoryId = productSubCategoryId;
	}

	public String getProductSubCategoryType() {
		return productSubCategoryType;
	}

	public void setProductSubCategoryType(String productSubCategoryType) {
		this.productSubCategoryType = productSubCategoryType;
	}

	public ProductMainCategory getProductMainCategory() {
		return productMainCategory;
	}

	public void setProductMainCategory(ProductMainCategory productMainCategory) {
		this.productMainCategory = productMainCategory;
	}

	public List<Product> getProducts() {
		return products;
	}

	public void setProducts(List<Product> products) {
		this.products = products;
	}

	@Override
	public String toString() {
		return "ProductSubCategory [productSubCategoryId=" + productSubCategoryId + ", productSubCategoryType="
				+ productSubCategoryType + ", productMainCategory=" + productMainCategory + ", products=" + products
				+ "]";
	}


	
}
