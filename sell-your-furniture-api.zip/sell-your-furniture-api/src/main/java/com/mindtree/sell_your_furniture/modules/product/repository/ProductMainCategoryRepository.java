package com.mindtree.sell_your_furniture.modules.product.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.mindtree.sell_your_furniture.modules.product.entity.ProductMainCategory;

@Repository

public interface ProductMainCategoryRepository extends JpaRepository<ProductMainCategory,Integer>{

	public ProductMainCategory findByproductMainCategoryType(String type);

}