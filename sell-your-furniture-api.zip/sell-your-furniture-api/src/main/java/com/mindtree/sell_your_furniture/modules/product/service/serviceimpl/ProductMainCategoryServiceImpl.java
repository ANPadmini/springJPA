package com.mindtree.sell_your_furniture.modules.product.service.serviceimpl;

import java.util.ArrayList;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.sell_your_furniture.modules.product.dto.ProductMainCategoryDTO;
import com.mindtree.sell_your_furniture.modules.product.entity.ProductMainCategory;
import com.mindtree.sell_your_furniture.modules.product.repository.ProductMainCategoryRepository;
import com.mindtree.sell_your_furniture.modules.product.service.ProductMainCategoryService;

@Service
public class ProductMainCategoryServiceImpl implements ProductMainCategoryService {

	ModelMapper modelMapper = new ModelMapper();
	@Autowired
	ProductMainCategoryRepository productMainCategoryRepository;

	@Override
	public ProductMainCategoryDTO addMainCategory(ProductMainCategoryDTO mainCategoryDto) {

		ProductMainCategory mainCategory = convertDtoToEntity(mainCategoryDto);
		ProductMainCategory newMainCategory = productMainCategoryRepository.save(mainCategory);
		ProductMainCategoryDTO newmainCategoryDto = convertEntityToDto(newMainCategory);
		return newmainCategoryDto;
	}

	public ProductMainCategory convertDtoToEntity(ProductMainCategoryDTO mainCategoryDto) {
		return modelMapper.map(mainCategoryDto, ProductMainCategory.class);
	}

	public ProductMainCategoryDTO convertEntityToDto(ProductMainCategory mainCategory) {
		return modelMapper.map(mainCategory, ProductMainCategoryDTO.class);
	}

	@Override
    public List<ProductMainCategory> getAllMainCategory() {
        List<ProductMainCategory> mainCategories=new ArrayList<ProductMainCategory>();
            mainCategories=productMainCategoryRepository.findAll();
            //System.out.println("Inside service"+mainCategories);
            return mainCategories;
    }
}
