package com.mindtree.sell_your_furniture.modules.user.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

import com.mindtree.sell_your_furniture.modules.product.entity.Product;

@Entity
public class User {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int userId;
	private String userName;
	private String userEmail;
	private long userPhone;
	private String gender;

	@OneToOne(cascade=CascadeType.ALL,fetch=FetchType.LAZY)
	@JoinColumn(name="userId")
	private UserLogin userLogin;
	
	@Column(name = "verified")
	private boolean verified;

	@ManyToOne(cascade=CascadeType.ALL,fetch=FetchType.EAGER)
	private UserRole userRole;

	@OneToOne(mappedBy="user")
	 // @JoinColumn(name="user")
	private DisplayPicture displayPicture;
	
	@OneToMany(mappedBy="user",fetch=FetchType.LAZY)
	List<Product> products;

	@OneToMany(mappedBy="user",cascade=CascadeType.ALL,fetch=FetchType.LAZY)
	private List<Address> addresses;

	public User() {
		super();
		// TODO Auto-generated constructor stub
	}

	public User(int userId, String userName, String userEmail, long userPhone, String gender, UserLogin userLogin,
			boolean verified, UserRole userRole, List<Product> products, DisplayPicture displayPicture,
			List<Address> addresses) {
		super();
		this.userId = userId;
		this.userName = userName;
		this.userEmail = userEmail;
		this.userPhone = userPhone;
		this.gender = gender;
		this.userLogin = userLogin;
		this.verified = verified;
		this.userRole = userRole;
		this.products = products;
		this.displayPicture = displayPicture;
		this.addresses = addresses;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserEmail() {
		return userEmail;
	}

	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}

	public long getUserPhone() {
		return userPhone;
	}

	public void setUserPhone(long userPhone) {
		this.userPhone = userPhone;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public UserLogin getUserLogin() {
		return userLogin;
	}

	public void setUserLogin(UserLogin userLogin) {
		this.userLogin = userLogin;
	}

	public boolean isVerified() {
		return verified;
	}

	public void setVerified(boolean verified) {
		this.verified = verified;
	}

	public UserRole getUserRole() {
		return userRole;
	}

	public void setUserRole(UserRole userRole) {
		this.userRole = userRole;
	}

	public List<Product> getProducts() {
		return products;
	}

	public void setProducts(List<Product> products) {
		this.products = products;
	}

	public DisplayPicture getDisplayPicture() {
		return displayPicture;
	}

	public void setDisplayPicture(DisplayPicture displayPicture) {
		this.displayPicture = displayPicture;
	}

	public List<Address> getAddresses() {
		return addresses;
	}

	public void setAddresses(List<Address> addresses) {
		this.addresses = addresses;
	}

	@Override
	public String toString() {
		return "User [userId=" + userId + ", userName=" + userName + ", userEmail=" + userEmail + ", userPhone="
				+ userPhone + ", gender=" + gender + ", userLogin=" + userLogin + ", verified=" + verified
				+ ", userRole=" + userRole + ", products=" + products + ", displayPicture=" + displayPicture
				+ ", addresses=" + addresses + "]";
	}
	
	
	
		
}
