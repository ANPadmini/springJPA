package com.mindtree.sell_your_furniture.modules.product.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import javax.persistence.OneToMany;



@Entity
public class ProductMainCategory {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int productMainCategoryId;
	private String productMainCategoryType;
	
	@OneToMany(mappedBy="productMainCategory",cascade=CascadeType.ALL,fetch=FetchType.EAGER)
	private List<ProductSubCategory> productSubCategories;

	public ProductMainCategory() {
		super();
	}

	public ProductMainCategory(int productMainCategoryId, String productMainCategoryType,
			List<ProductSubCategory> productSubCategories) {
		super();
		this.productMainCategoryId = productMainCategoryId;
		this.productMainCategoryType = productMainCategoryType;
		this.productSubCategories = productSubCategories;
	}

	public int getProductMainCategoryId() {
		return productMainCategoryId;
	}

	public void setProductMainCategoryId(int productMainCategoryId) {
		this.productMainCategoryId = productMainCategoryId;
	}

	public String getProductMainCategoryType() {
		return productMainCategoryType;
	}

	public void setProductMainCategoryType(String productMainCategoryType) {
		this.productMainCategoryType = productMainCategoryType;
	}

	public List<ProductSubCategory> getProductSubCategories() {
		return productSubCategories;
	}

	public void setProductSubCategories(List<ProductSubCategory> productSubCategories) {
		this.productSubCategories = productSubCategories;
	}

	@Override
	public String toString() {
		return "ProductMainCategory [productMainCategoryId=" + productMainCategoryId + ", productMainCategoryType="
				+ productMainCategoryType + ", productSubCategories=" + productSubCategories + "]";
	}

	
	
}
