package com.mindtree.sell_your_furniture.modules.user.service;

public interface UserLoginService {

	public String encrypt(String originalString, String secretKey);

	public String decrypt(String encryptedString, String secretKey);
	
	
}
