package com.mindtree.sell_your_furniture.modules.verificationtoken.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mindtree.sell_your_furniture.modules.verificationtoken.entity.ResetToken;

public interface ResetTokenRepository extends JpaRepository<ResetToken, Integer>{
	ResetToken findByToken(String confirmationToken);
}
