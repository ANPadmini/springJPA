package com.mindtree.sell_your_furniture.modules.user.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class Address {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int addressId;
	private String locality;
	private String district;
	private String State;
	private int pincode;
	private String landmark;
	private String addressType;
	
	@ManyToOne
	private User user;

	public Address() {
		super();
	}

	public Address(int addressId, String locality, String district, String state, int pincode, String landmark,
			String addressType, User user) {
		super();
		this.addressId = addressId;
		this.locality = locality;
		this.district = district;
		State = state;
		this.pincode = pincode;
		this.landmark = landmark;
		this.addressType = addressType;
		this.user = user;
	}

	public int getAddressId() {
		return addressId;
	}

	public void setAddressId(int addressId) {
		this.addressId = addressId;
	}

	public String getLocality() {
		return locality;
	}

	public void setLocality(String locality) {
		this.locality = locality;
	}

	public String getDistrict() {
		return district;
	}

	public void setDistrict(String district) {
		this.district = district;
	}

	public String getState() {
		return State;
	}

	public void setState(String state) {
		State = state;
	}

	public int getPincode() {
		return pincode;
	}

	public void setPincode(int pincode) {
		this.pincode = pincode;
	}

	public String getLandmark() {
		return landmark;
	}

	public void setLandmark(String landmark) {
		this.landmark = landmark;
	}

	public String getAddressType() {
		return addressType;
	}

	public void setAddressType(String addressType) {
		this.addressType = addressType;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	@Override
	public String toString() {
		return "Address [addressId=" + addressId + ", locality=" + locality + ", district=" + district + ", State="
				+ State + ", pincode=" + pincode + ", landmark=" + landmark + ", addressType=" + addressType + ", user="
				+ user + "]";
	}


}
