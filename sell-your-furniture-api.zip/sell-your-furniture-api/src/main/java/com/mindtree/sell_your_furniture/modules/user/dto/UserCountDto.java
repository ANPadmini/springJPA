package com.mindtree.sell_your_furniture.modules.user.dto;

public class UserCountDto {

	private int sellers;
	private int buyers;

	public UserCountDto() {
		super();
	}

	public UserCountDto(int sellers, int buyers) {
		super();
		this.sellers = sellers;
		this.buyers = buyers;
	}

	public int getSellers() {
		return sellers;
	}

	public void setSellers(int sellers) {
		this.sellers = sellers;
	}

	public int getBuyers() {
		return buyers;
	}

	public void setBuyers(int buyers) {
		this.buyers = buyers;
	}

}
