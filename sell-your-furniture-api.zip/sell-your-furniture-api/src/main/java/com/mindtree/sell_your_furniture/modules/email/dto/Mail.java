package com.mindtree.sell_your_furniture.modules.email.dto;

public class Mail {

}
