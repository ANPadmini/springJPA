package com.mindtree.sell_your_furniture.properties;

public class AppDevelopmentProp {

}
