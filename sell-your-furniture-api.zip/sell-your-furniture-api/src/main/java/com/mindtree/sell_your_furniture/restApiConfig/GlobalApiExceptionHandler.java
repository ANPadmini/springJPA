package com.mindtree.sell_your_furniture.restApiConfig;


import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.mindtree.sell_your_furniture.exception.serviceException.ServiceException;
import com.mindtree.sell_your_furniture.modules.admin.controller.AdminController;
import com.mindtree.sell_your_furniture.modules.product.controller.ProductController;
import com.mindtree.sell_your_furniture.modules.user.controller.UserController;
import com.mindtree.sell_your_furniture.restApiConfig.model.ApiSuccessResponse;

@RestControllerAdvice(assignableTypes = { UserController.class,AdminController.class,ProductController.class })
public class GlobalApiExceptionHandler {
	    @ExceptionHandler(ServiceException.class)
	    public ResponseEntity<ApiSuccessResponse> ServiceExceptionhandler(Exception e, Throwable cause) {
	    	ApiSuccessResponse response = new ApiSuccessResponse("Exception Message", true, e.getMessage(), HttpStatus.BAD_REQUEST);
	        return new ResponseEntity<ApiSuccessResponse>(response, HttpStatus.OK);
	    }
}

