package com.mindtree.sell_your_furniture.modules.product.controller;

import java.util.ArrayList;

import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.mindtree.sell_your_furniture.modules.product.dto.ProductDTO;
import com.mindtree.sell_your_furniture.modules.product.dto.ProductInputDTO;
import com.mindtree.sell_your_furniture.modules.product.dto.ProductMainCategoryDTO;
import com.mindtree.sell_your_furniture.modules.product.dto.ProductMaterialDTO;
import com.mindtree.sell_your_furniture.modules.product.entity.Product;
import com.mindtree.sell_your_furniture.modules.product.entity.ProductImage;
import com.mindtree.sell_your_furniture.modules.product.entity.ProductMainCategory;
import com.mindtree.sell_your_furniture.modules.product.entity.ProductMaterial;
import com.mindtree.sell_your_furniture.modules.product.service.ProductImageService;
import com.mindtree.sell_your_furniture.modules.product.service.ProductMainCategoryService;
import com.mindtree.sell_your_furniture.modules.product.service.ProductMaterialService;
import com.mindtree.sell_your_furniture.modules.product.service.ProductService;

import com.mindtree.sell_your_furniture.restApiConfig.model.ApiSuccessResponse;

import io.swagger.annotations.Api;

@RestController
@RequestMapping("/syf/product")
@CrossOrigin
@Api(value = "Operations pertaining to products in Sell Your Furniture")
public class ProductController {

	@Autowired
	ProductMainCategoryService mainCategory;

	@Autowired
	ProductMainCategoryService subCategory;

	@Autowired
	ProductMaterialService productMaterialService;

	@Autowired
	ProductImageService productImageService;

	@Autowired
	ProductService productService;


	public ModelMapper mapper = new ModelMapper();


	
	
	@GetMapping("/main-category")
	public ResponseEntity<ApiSuccessResponse> getMainCategory(){
		System.out.println("Inside Main category");
		List<ProductMainCategory> mainCategories=mainCategory.getAllMainCategory();
		List<ProductMainCategoryDTO> mainCategoryDtos=new ArrayList<ProductMainCategoryDTO>();
		
		mainCategories.forEach(mainCategory->{
			//System.out.println("SIZE IS:"+mainCategory.getProductSubCategories().get(0).getProductSubCategoryType());
			ProductMainCategoryDTO mainCategoryDto=mapper.map(mainCategory, ProductMainCategoryDTO.class);
			
			mainCategoryDtos.add(mainCategoryDto);
			
			
			
			
			/*mainCategoryDto.setProductMainCategoryId(mainCategory.getProductMainCategoryId());
			mainCategoryDto.setProductMainCategoryType(mainCategory.getProductMainCategoryType());
			mainCategoryDto.setProductSubCategoriesDto(mainCategory.getProductSubCategories());
			
			//To avoid Jackson Error
			mainCategoryDto.getProductSubCategoriesDto().forEach(subCategory->{

				subCategory.setProducts(null);
			});
			mainCategoryDtos.add(mainCategoryDto);
*/		});
		//System.out.println("SIZE OF SUB-DTOS"+mainCategoryDtos.get(0).getProductSubCategoriesDto().size());
		return new ResponseEntity<ApiSuccessResponse>(
				new ApiSuccessResponse("main category list", false, mainCategoryDtos, HttpStatus.OK), HttpStatus.OK);

	}



	@GetMapping("/material")
	public ResponseEntity<ApiSuccessResponse> getMaterial(){
		
		List<ProductMaterial> productMaterials=productMaterialService.getAllMaterial();
		List<ProductMaterialDTO> productMaterialDtos=new ArrayList<ProductMaterialDTO>();
		productMaterials.forEach(material->{
			ProductMaterialDTO materialDto=mapper.map(material, ProductMaterialDTO.class);

			productMaterialDtos.add(materialDto);

		});

		
		
		
		return new ResponseEntity<ApiSuccessResponse>(new ApiSuccessResponse("main category list", false, productMaterialDtos, HttpStatus.OK),HttpStatus.OK);
		

	}

	@PostMapping(value = "/image/{productId}")
	public String storeFile(@PathVariable int productId, @RequestParam List<MultipartFile> files) {
		System.out.println("Image" + files);
		List<ProductImage> images = null;

		images = productImageService.storeFile(productId, files);

		return "insnerted";

	}

	@PostMapping("/new-product/{userId}")

	public ResponseEntity<ApiSuccessResponse> addProduct(@PathVariable int userId,@RequestBody ProductInputDTO productDto){
	

		System.out.println("In Controller");
		Product product = new Product();
		product.setProductTitle(productDto.getProductTitle());
		product.setProductPrice(productDto.getProductPrice());
		product.setProductDescription(productDto.getProductDescription());
		System.out.println(productDto);

		Product savedProduct = productService.saveProduct(product, userId, productDto.getProductMainCategory(),
				productDto.getProductSubCategory(), productDto.getProductMaterial());

		
		
	ProductDTO savedProductDto=mapper.map(savedProduct, ProductDTO.class);
	return new ResponseEntity<ApiSuccessResponse>(new ApiSuccessResponse("main category list", false,savedProductDto, HttpStatus.OK),HttpStatus.OK);
		
	}
	
}




