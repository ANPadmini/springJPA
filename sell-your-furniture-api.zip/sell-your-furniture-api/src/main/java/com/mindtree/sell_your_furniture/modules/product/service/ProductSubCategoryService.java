package com.mindtree.sell_your_furniture.modules.product.service;

import java.util.List;

import com.mindtree.sell_your_furniture.modules.product.dto.ProductSubCategoryDTO;
import com.mindtree.sell_your_furniture.modules.product.entity.ProductSubCategory;

public interface ProductSubCategoryService {

	public List<ProductSubCategoryDTO> addSubCategory(List<ProductSubCategoryDTO> productSubCategoryDto,String mainCategory);

}
