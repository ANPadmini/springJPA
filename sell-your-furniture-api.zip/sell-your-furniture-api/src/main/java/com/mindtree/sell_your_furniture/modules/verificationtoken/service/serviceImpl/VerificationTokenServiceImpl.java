package com.mindtree.sell_your_furniture.modules.verificationtoken.service.serviceImpl;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMailMessage;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import com.mindtree.sell_your_furniture.modules.email.service.EmailService;
import com.mindtree.sell_your_furniture.modules.user.entity.User;
import com.mindtree.sell_your_furniture.modules.user.repository.UserRepository;
import com.mindtree.sell_your_furniture.modules.verificationtoken.entity.VerificationToken;
import com.mindtree.sell_your_furniture.modules.verificationtoken.repository.VerificationTokenRepository;
import com.mindtree.sell_your_furniture.modules.verificationtoken.service.VerificationTokenService;

@Service
public class VerificationTokenServiceImpl implements VerificationTokenService {

	@Autowired
	VerificationTokenRepository verificationTokenRepository;

	@Autowired
	private EmailService emailService;

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private JavaMailSender emailSender;

	@Override
	public String addToken(User user) {
		VerificationToken verificationToken = new VerificationToken(user);

		verificationTokenRepository.save(verificationToken);
		MimeMessage message = emailSender.createMimeMessage();
		MimeMessageHelper mailMessage = new MimeMessageHelper(message);
		// MimeMailMessage mailMessage = new MimeMailMessage();
		try {
			mailMessage.setTo(user.getUserEmail());
		} catch (MessagingException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try {
			mailMessage.setSubject("Please Complete your Registration on SELL YOUR FURNITURE!");
		} catch (MessagingException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try {
			mailMessage.setFrom("anandkunal2012@gmail.com");
		} catch (MessagingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// mailMessage.setText("To confirm your account, please click here : " +
		// "http://localhost:4200/verification?token="
		// + verificationToken.getConfirmationToken());
		try {
			
			message.setContent("<!DOCTYPE html>\r\n" + 
					"<html>\r\n" + 
					"<head>\r\n" + 
					"<style>\r\n" + 
					".button {\r\n" + 
					"  background-color: green; /* Green */\r\n" + 
					"  border: none;\r\n" + 
					"  color: white;\r\n" + 
					"  padding: 16px 32px;\r\n" + 
					"  text-align: center;\r\n" + 
					"  text-decoration: none;\r\n" + 
					"  display: inline-block;\r\n" + 
					"  font-size: 16px;\r\n" + 
					"  margin: 4px 2px;\r\n" + 
					"  -webkit-transition-duration: 0.4s; /* Safari */\r\n" + 
					"  transition-duration: 0.4s;\r\n" + 
					"  cursor: pointer;\r\n" + 
					"}\r\n" + 
					"\r\n" + 
					".button1 {\r\n" + 
					"  background-color:#FFDAB9; \r\n" + 
					"  color: white; \r\n" + 
					"  border: 2px solid;\r\n" + 
					"}\r\n" + 
					"\r\n" + 
					".button1:hover {\r\n" + 
					"  background-color: #4CAF50;\r\n" + 
					"  color: white;\r\n" + 
					"}\r\n" + 
					"\r\n" + 
					"</style>\r\n" + 
					"</head>\r\n" + 
					"<body style='border-radius: 25px;\r\n" + 
					"  background: url(https://www.inwhatlanguage.com/wp-content/uploads/2016/09/plain-light-color-for-guest-background.jpg);\r\n" + 
					"  background-position: left top;\r\n" + 
					"  background-repeat: repeat;'>\r\n" + 
					"\r\n" + 
					"<center><h1 style='color:#8B0000'>Dear "+user.getUserName()+"</h1><hr><h2>GREETINGS AND WARM WELCOME TO SELL YOUR FURNITURE</h2>\r\n" + 
					"<h3><b>Plese Verify Your email address by clicking on the button below. </h3>\r\n" + 
					"\r\n" + 
					"\r\n" + 
					"<button class=\'button button1\'><a href='http://localhost:4200/verification?token="+verificationToken.getConfirmationToken()+"'>Verify Your Account</a></button>\r\n" + 
					"\r\n <h3>NOTE: KINDLY IGNORE IF THIS WAS NOT YOU. </h3>" + 
					"\r\n" + 
					"</body>\r\n" + 
					"</html>\r\n" + 
					"","text/html");
			
		/*	message.setContent("<html lang=\"en\">\r\n" + "  <head>\r\n" + "    <meta charset=\"UTF-8\" />\r\n"
					+ "    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\" />\r\n"
					+ "    <meta http-equiv=\"X-UA-Compatible\" content=\"ie=edge\" />\r\n"
					+ "    <title>Document</title>\r\n" + "  </head>\r\n" + "  <body>\r\n" + "    <h4><strong>Dear "
					+ user.getUserName() + "</strong></h4>\r\n" + "    <br />\r\n" + "    <h3>\r\n"
					+ "      Welcome to Sell Your Furniture. Please Confirm Your Account. Click here \"http://localhost:4200/verification?token="
					+ verificationToken.getConfirmationToken() + "    </h3>\r\n" + "  </body>\r\n" + "</html>",
					"text/html");*/
		} catch (MessagingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// emailService.sendEmail(mailMessage);
		emailSender.send(message);
		return null;
	}

	public String validateUserByToken(String confirmationToken) {
		VerificationToken token = verificationTokenRepository.findByConfirmationToken(confirmationToken);
		if (token != null) {
			User user = userRepository.findByUserEmailIgnoreCase(token.getUser().getUserEmail());
			user.setVerified(true);
			userRepository.save(user);
			return "Validation Successfull";
		} else {
			return "Not valid User";
		}
	}

}
