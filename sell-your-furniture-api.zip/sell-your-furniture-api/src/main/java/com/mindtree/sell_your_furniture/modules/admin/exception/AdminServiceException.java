package com.mindtree.sell_your_furniture.modules.admin.exception;

public class AdminServiceException {

}
