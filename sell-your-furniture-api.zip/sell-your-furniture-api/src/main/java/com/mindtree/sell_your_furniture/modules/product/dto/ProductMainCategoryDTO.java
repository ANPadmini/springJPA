package com.mindtree.sell_your_furniture.modules.product.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.mindtree.sell_your_furniture.modules.product.entity.ProductSubCategory;

public class ProductMainCategoryDTO {

	private int productMainCategoryId;
	private String productMainCategoryType;

	@JsonIgnoreProperties("productMainCategoriesDto")
	private List<ProductSubCategoryDTO> productSubCategoriesDto;

	public ProductMainCategoryDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ProductMainCategoryDTO(int productMainCategoryId, String productMainCategoryType,
			List<ProductSubCategoryDTO> productSubCategoriesDto) {
		super();
		this.productMainCategoryId = productMainCategoryId;
		this.productMainCategoryType = productMainCategoryType;
		this.productSubCategoriesDto = productSubCategoriesDto;
	}

	public int getProductMainCategoryId() {
		return productMainCategoryId;
	}

	public void setProductMainCategoryId(int productMainCategoryId) {
		this.productMainCategoryId = productMainCategoryId;
	}

	public String getProductMainCategoryType() {
		return productMainCategoryType;
	}

	public void setProductMainCategoryType(String productMainCategoryType) {
		this.productMainCategoryType = productMainCategoryType;
	}

	public List<ProductSubCategoryDTO> getProductSubCategoriesDto() {
		return productSubCategoriesDto;
	}

	public void setProductSubCategoriesDto(List<ProductSubCategoryDTO> productSubCategoriesDto) {
		this.productSubCategoriesDto = productSubCategoriesDto;
	}

	
}
