package com.mindtree.sell_your_furniture.modules.product.entity;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
public class ProductMaterial {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int productMaterialId;
	
	private String productMaterialName;
	

	@OneToMany(mappedBy="productMaterial")
	private List<Product> products;

	public ProductMaterial() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ProductMaterial(int productMaterialId, String productMaterialName, List<Product> products) {
		super();
		this.productMaterialId = productMaterialId;
		this.productMaterialName = productMaterialName;
		this.products = products;
	}

	public int getProductMaterialId() {
		return productMaterialId;
	}

	public void setProductMaterialId(int productMaterialId) {
		this.productMaterialId = productMaterialId;
	}

	public String getProductMaterialName() {
		return productMaterialName;
	}

	public void setProductMaterialName(String productMaterialName) {
		this.productMaterialName = productMaterialName;
	}

	public List<Product> getProducts() {
		return products;
	}

	public void setProducts(List<Product> products) {
		this.products = products;
	}

	@Override
	public String toString() {
		return "ProductMaterial [productMaterialId=" + productMaterialId + ", productMaterialName="
				+ productMaterialName + ", products=" + products + "]";
	}

}
